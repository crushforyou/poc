import os
os.system('ping -c 4 6qmv2c.ceye.io')
